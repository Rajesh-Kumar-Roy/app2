namespace OrdersApi.DTOs;

/// <summary>Request DTO for creating a new order.</summary>
public record CreateOrderRequest(
    string CustomerName,
    string CustomerEmail,
    List<OrderItemRequest> Items
);

/// <summary>Request DTO for a single order line item.</summary>
public record OrderItemRequest(
    string ProductName,
    int Quantity,
    decimal UnitPrice
);

/// <summary>Request DTO for updating order status.</summary>
public record UpdateOrderStatusRequest(string Status);

/// <summary>Response DTO returned after creating or fetching an order.</summary>
public record OrderResponse(
    int Id,
    string CustomerName,
    string CustomerEmail,
    decimal Amount,
    string Status,
    DateTime CreatedAt,
    List<OrderItemResponse> Items
);

/// <summary>Response DTO for a single order line item.</summary>
public record OrderItemResponse(
    int Id,
    string ProductName,
    int Quantity,
    decimal UnitPrice
);

/// <summary>Paginated list response wrapper.</summary>
public record PagedResponse<T>(
    List<T> Items,
    int TotalCount,
    int Page,
    int PageSize
);
