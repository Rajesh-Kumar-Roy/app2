# Orders API — Claude Code Project Instructions

## Stack
- Language : C# (.NET 10)
- Framework: ASP.NET Core 10 — controller pattern (NOT minimal APIs)
- ORM      : Entity Framework Core (InMemory for demo, swap to SQL Server in prod)
- Validation: FluentValidation
- Testing  : xUnit + Moq
- Docs     : Swagger / Swashbuckle

## Folder layout — never put files in the wrong folder
```
Controllers/    API surface only — no business logic
DTOs/           Request and Response records
Models/         EF Core entity classes
Repositories/   IXxxRepository interface + XxxRepository implementation
Validators/     FluentValidation validators
Data/           AppDbContext only
Middleware/     Global error handler
Tests/          xUnit test files (named XxxTests.cs)
```

## C# rules (enforced by csharp-reviewer agent)
- async/await everywhere — never .Result or .Wait()
- Nullable reference types enabled — handle nulls explicitly, no null!
- All public methods must have XML doc comments
- DTOs are records, Entities are classes
- Controllers inject via constructor, validate first, then call repository
- Return ProblemDetails (RFC 7807) on all errors
- No business logic in controllers — only: validate → call repo → map → return

## EF Core rules (enforced by efcore-agent)
- Use .AsNoTracking() on all read-only queries
- Always .Include() related data — no lazy loading
- Check for N+1 queries before saving any query code

## Testing rules (enforced by test-writer agent)
- One test file per class being tested (e.g. OrdersControllerTests.cs)
- Test method names: MethodName_Scenario_ExpectedResult
- Use Moq to mock all dependencies
- Cover: happy path, not found, validation failure

## When you add a new feature
Always follow this order:
1. Models (entity)
2. DTOs (request + response records)
3. Validator
4. Repository (interface + implementation)
5. Controller action
6. Register in Program.cs
7. Tests
