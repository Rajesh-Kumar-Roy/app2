using Microsoft.EntityFrameworkCore;
using OrdersApi.Data;
using OrdersApi.Models;

namespace OrdersApi.Repositories;

/// <summary>Defines data access operations for orders.</summary>
public interface IOrderRepository
{
    Task<(List<Order> Orders, int Total)> GetAllAsync(int page, int pageSize);
    Task<Order?> GetByIdAsync(int id);
    Task<Order> CreateAsync(Order order);
    Task<Order?> UpdateStatusAsync(int id, string status);
    Task<bool> DeleteAsync(int id);
}

/// <summary>EF Core implementation of the order repository.</summary>
public class OrderRepository(AppDbContext db) : IOrderRepository
{
    /// <summary>Returns a paginated list of all orders.</summary>
    public async Task<(List<Order> Orders, int Total)> GetAllAsync(int page, int pageSize)
    {
        var total = await db.Orders.CountAsync();

        var orders = await db.Orders
            .Include(o => o.Items)
            .OrderByDescending(o => o.CreatedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        return (orders, total);
    }

    /// <summary>Returns a single order by ID, including its items.</summary>
    public async Task<Order?> GetByIdAsync(int id) =>
        await db.Orders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.Id == id);

    /// <summary>Saves a new order and returns the saved entity.</summary>
    public async Task<Order> CreateAsync(Order order)
    {
        db.Orders.Add(order);
        await db.SaveChangesAsync();
        return order;
    }

    /// <summary>Updates the status of an existing order.</summary>
    public async Task<Order?> UpdateStatusAsync(int id, string status)
    {
        var order = await db.Orders.FindAsync(id);
        if (order is null) return null;

        order.Status = status;
        await db.SaveChangesAsync();
        return order;
    }

    /// <summary>Soft-deletes an order. Returns false if not found.</summary>
    public async Task<bool> DeleteAsync(int id)
    {
        var order = await db.Orders.FindAsync(id);
        if (order is null) return false;

        db.Orders.Remove(order);
        await db.SaveChangesAsync();
        return true;
    }
}
