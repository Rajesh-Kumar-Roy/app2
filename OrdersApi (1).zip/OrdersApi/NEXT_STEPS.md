# How to use the Claude Code agents in this project

This file shows you exactly what to type in Claude Code to use each agent,
skill, slash command, and the orchestrator. Copy and paste these examples.

---

## First — open this project in Claude Code

```bash
cd OrdersApi
claude
```

---

## 1. CLAUDE.md — nothing to do, it works automatically

Claude reads CLAUDE.md every time you start. You do not need to do anything.
Just edit CLAUDE.md if you want to change a project rule.

---

## 2. Skills — used automatically, but you can also mention them

Skills load automatically when relevant. You can also reference them directly:

```
Read the aspnet-endpoint skill and tell me the steps to create a new endpoint
```

```
Read the efcore skill and explain how to write a read query correctly
```

```
Read the xunit-testing skill and show me the test naming convention
```

---

## 3. Sub-agents — type their name + what to do

### csharp-reviewer — review any C# file

```
csharp-reviewer, review Controllers/OrdersController.cs
```

```
csharp-reviewer, review all files in Repositories/
```

```
csharp-reviewer, review the new code I just wrote in Validators/OrderValidators.cs
```

### efcore-agent — database and EF Core tasks

```
efcore-agent, add a new Product entity with fields: Name (string), Price (decimal), Stock (int)
```

```
efcore-agent, add a Customer entity with Name, Email, Phone and link it to Orders
```

```
efcore-agent, review the queries in Repositories/OrderRepository.cs for N+1 issues
```

### test-writer — write tests for any class

```
test-writer, write xUnit tests for Controllers/OrdersController.cs
```

```
test-writer, write tests for Validators/OrderValidators.cs
```

```
test-writer, write tests for Repositories/OrderRepository.cs
```

---

## 4. Slash commands — type / then the command name

### /new-endpoint — add one endpoint to an existing controller

```
/new-endpoint GET /api/orders/customer/{email} — find all orders by customer email
```

```
/new-endpoint POST /api/orders/{id}/cancel — cancel an existing order
```

```
/new-endpoint GET /api/orders/status/{status} — filter orders by status
```

### /new-feature — build a complete new resource from scratch

```
/new-feature Products — with Name, Price, Stock, Category fields
```

```
/new-feature Customers — with Name, Email, Phone, Address fields
```

```
/new-feature Suppliers — with CompanyName, ContactEmail, Country fields
```

### /review-all — review the whole codebase at once

```
/review-all
```

---

## 5. Orchestrator — for large features, type its name like an agent

```
orchestrator, build a complete Products feature with full CRUD endpoints
```

```
orchestrator, add a Customers module with Name, Email, Phone and link customers to their orders
```

```
orchestrator, build a complete reporting module that returns order totals by date range
```

---

## Typical workflow for adding a new feature

Here is what a beginner should do when adding, for example, a Products feature:

### Option A — let the orchestrator do everything (easiest)
```
orchestrator, build a complete Products feature with Name, Price, Stock, Category
```
Wait. It will create all files and report back.

### Option B — do it step by step yourself (learn more)

Step 1 — add the database entity:
```
efcore-agent, add a Product entity with Name (string, max 200), Price (decimal), Stock (int), CreatedAt (DateTime)
```

Step 2 — build the API:
```
/new-feature Products
```

Step 3 — review the code:
```
csharp-reviewer, review all new files in Controllers/, Repositories/, Validators/
```

Step 4 — write tests:
```
test-writer, write xUnit tests for Controllers/ProductsController.cs
```

---

## Quick reference card

| What you want to do                  | What to type                                      |
|--------------------------------------|---------------------------------------------------|
| Add one new endpoint                 | /new-endpoint [describe the endpoint]             |
| Build a whole new feature            | /new-feature [resource name and fields]           |
| Review a specific file               | csharp-reviewer, review [filename]                |
| Review everything                    | /review-all                                       |
| Add a new database table             | efcore-agent, add [entity] with fields [...]      |
| Write tests for a class              | test-writer, write tests for [filename]           |
| Build a big feature automatically    | orchestrator, build [feature description]         |

---

## If something goes wrong

If Claude gives you an error or the output looks wrong:

1. Ask it to explain: `what went wrong with the last step?`
2. Ask it to retry: `try again, but this time read the aspnet-endpoint skill first`
3. Ask for help: `explain what csharp-reviewer found and how to fix each issue`
