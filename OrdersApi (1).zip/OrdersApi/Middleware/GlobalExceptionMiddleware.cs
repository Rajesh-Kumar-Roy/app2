using System.Net;
using System.Text.Json;

namespace OrdersApi.Middleware;

/// <summary>
/// Global exception handler that returns RFC 7807 ProblemDetails on unhandled errors.
/// </summary>
public class GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled exception for {Method} {Path}", 
                context.Request.Method, context.Request.Path);

            await WriteErrorResponse(context, ex);
        }
    }

    private static async Task WriteErrorResponse(HttpContext context, Exception ex)
    {
        context.Response.ContentType = "application/problem+json";
        context.Response.StatusCode  = (int)HttpStatusCode.InternalServerError;

        var problem = new
        {
            type     = "https://tools.ietf.org/html/rfc7807",
            title    = "An unexpected error occurred.",
            status   = 500,
            detail   = ex.Message,
            instance = context.Request.Path.Value
        };

        var json = JsonSerializer.Serialize(problem, new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        await context.Response.WriteAsync(json);
    }
}
