using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using OrdersApi.DTOs;
using OrdersApi.Models;
using OrdersApi.Repositories;

namespace OrdersApi.Controllers;

/// <summary>
/// Manages CRUD operations for customer orders.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class OrdersController(
    IOrderRepository repository,
    IValidator<CreateOrderRequest> createValidator,
    IValidator<UpdateOrderStatusRequest> statusValidator) : ControllerBase
{
    /// <summary>Returns a paginated list of all orders.</summary>
    /// <param name="page">Page number (default: 1)</param>
    /// <param name="pageSize">Items per page (default: 10, max: 50)</param>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResponse<OrderResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] int page = 1, [FromQuery] int pageSize = 10)
    {
        pageSize = Math.Min(pageSize, 50);
        var (orders, total) = await repository.GetAllAsync(page, pageSize);

        var response = new PagedResponse<OrderResponse>(
            Items: orders.Select(MapToResponse).ToList(),
            TotalCount: total,
            Page: page,
            PageSize: pageSize
        );

        return Ok(response);
    }

    /// <summary>Returns a single order by its ID.</summary>
    /// <param name="id">The order ID</param>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(OrderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id)
    {
        var order = await repository.GetByIdAsync(id);
        if (order is null)
            return NotFound(new { message = $"Order {id} not found." });

        return Ok(MapToResponse(order));
    }

    /// <summary>Creates a new order.</summary>
    /// <param name="request">The order details</param>
    [HttpPost]
    [ProducesResponseType(typeof(OrderResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateOrderRequest request)
    {
        var validation = await createValidator.ValidateAsync(request);
        if (!validation.IsValid)
            return ValidationProblem(validation.ToDictionary());

        var order = new Order
        {
            CustomerName  = request.CustomerName,
            CustomerEmail = request.CustomerEmail,
            Items = request.Items.Select(i => new OrderItem
            {
                ProductName = i.ProductName,
                Quantity    = i.Quantity,
                UnitPrice   = i.UnitPrice
            }).ToList()
        };

        order.Amount = order.Items.Sum(i => i.Quantity * i.UnitPrice);

        var created = await repository.CreateAsync(order);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, MapToResponse(created));
    }

    /// <summary>Updates the status of an existing order.</summary>
    /// <param name="id">The order ID</param>
    /// <param name="request">The new status</param>
    [HttpPatch("{id:int}/status")]
    [ProducesResponseType(typeof(OrderResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateOrderStatusRequest request)
    {
        var validation = await statusValidator.ValidateAsync(request);
        if (!validation.IsValid)
            return ValidationProblem(validation.ToDictionary());

        var updated = await repository.UpdateStatusAsync(id, request.Status);
        if (updated is null)
            return NotFound(new { message = $"Order {id} not found." });

        return Ok(MapToResponse(updated));
    }

    /// <summary>Deletes an order by ID.</summary>
    /// <param name="id">The order ID</param>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await repository.DeleteAsync(id);
        if (!deleted)
            return NotFound(new { message = $"Order {id} not found." });

        return NoContent();
    }

    // ── Mapping helper ────────────────────────────────────────────────
    private static OrderResponse MapToResponse(Order o) => new(
        Id:            o.Id,
        CustomerName:  o.CustomerName,
        CustomerEmail: o.CustomerEmail,
        Amount:        o.Amount,
        Status:        o.Status,
        CreatedAt:     o.CreatedAt,
        Items: o.Items.Select(i => new OrderItemResponse(
            Id:          i.Id,
            ProductName: i.ProductName,
            Quantity:    i.Quantity,
            UnitPrice:   i.UnitPrice
        )).ToList()
    );
}
