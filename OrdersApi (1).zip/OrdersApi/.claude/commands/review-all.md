# /review-all — reviews all C# files in the project

Review all C# code in this project for quality issues.

## Instructions

1. Read CLAUDE.md to understand the project rules
2. Find all .cs files in these folders:
   - Controllers/
   - Repositories/
   - Validators/
   - Models/
   - Data/
   - Middleware/
3. For each file, apply the full csharp-reviewer checklist:
   - Async/await correctness
   - Null safety
   - Architecture (no logic in controllers)
   - XML doc comments
   - EF Core patterns (AsNoTracking, Include)
4. Collect ALL issues across all files
5. Report in this format:

## Review Report

### Critical issues (fix before running)
- FILE: Controllers/X.cs | LINE: ~20 | ISSUE: ... | FIX: ...

### Warnings (should fix soon)
- FILE: Repositories/X.cs | LINE: ~45 | ISSUE: ... | FIX: ...

### Passed (no issues)
- Controllers/OrdersController.cs ✅
- Repositories/OrderRepository.cs ✅

### Summary
- X critical issues
- X warnings
- X files clean
