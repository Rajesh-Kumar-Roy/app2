# /new-endpoint — creates a single new API endpoint

Build a new ASP.NET Core 10 endpoint for: $ARGUMENTS

## Instructions
Read the aspnet-endpoint skill first, then follow these steps in order:

1. Read existing DTOs/ and Controllers/ to understand the current patterns
2. Create Request + Response DTO records in DTOs/
3. Create FluentValidation validator in Validators/
4. Add repository method to the appropriate interface and implementation in Repositories/
   (if a new resource, create a new repository file)
5. Add the controller action in Controllers/
   (if a new resource, create a new controller file)
6. Register any new services in Program.cs
7. Ask csharp-reviewer to review all new or changed files
8. Report: files created, endpoint URL, how to test it in Swagger

## Rules
- Follow patterns already in the project — read existing files first
- XML doc comments on every public method
- ProducesResponseType on every controller action
- Validate before doing anything else in the action
