# /new-feature — builds a complete CRUD feature end-to-end

Build a complete backend feature for: $ARGUMENTS

## What this command does
This creates EVERYTHING needed for a new resource — entity, DTOs, validator,
repository, controller, and tests. Use this when adding a brand new resource.

## Steps — follow in this exact order

### Phase 1: Data layer
1. Read existing Models/ and Data/AppDbContext.cs to understand current patterns
2. Read the efcore skill (.claude/skills/efcore/SKILL.md)
3. Create the entity class in Models/
4. Add DbSet to AppDbContext
5. Configure entity in OnModelCreating (with seed data if helpful)

### Phase 2: API layer (can start after Phase 1)
6. Read the aspnet-endpoint skill (.claude/skills/aspnet-endpoint/SKILL.md)
7. Create Request + Response DTOs in DTOs/
8. Create FluentValidation validator in Validators/
9. Create IXxxRepository interface + XxxRepository implementation in Repositories/
10. Create XxxController in Controllers/ with full CRUD:
    - GET /api/xxx (list, paginated)
    - GET /api/xxx/{id} (single)
    - POST /api/xxx (create)
    - PATCH /api/xxx/{id}/status or relevant update
    - DELETE /api/xxx/{id}
11. Register everything in Program.cs

### Phase 3: Review + Tests
12. Ask csharp-reviewer to review ALL new files
13. Read xunit-testing skill (.claude/skills/xunit-testing/SKILL.md)
14. Write xUnit tests in Tests/ covering:
    - Happy path for each endpoint
    - Not found scenarios
    - Validation failure scenarios

## Final report format
After completing all steps, report:

### Feature built: [Name]
**Files created:** (list every file)
**Endpoints:**
  - GET    /api/xxx
  - GET    /api/xxx/{id}
  - POST   /api/xxx
  - DELETE /api/xxx/{id}
**Test file:** Tests/XxxControllerTests.cs
**How to test:** dotnet run → open http://localhost:5000
