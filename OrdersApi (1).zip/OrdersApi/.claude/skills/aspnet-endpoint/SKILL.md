---
name: aspnet-endpoint
description: Use when creating a new ASP.NET Core controller, endpoint,
             DTO, or FluentValidation validator. Triggers on phrases like
             "new endpoint", "add API", "create controller", "new route".
---

# How to create a new ASP.NET Core 10 endpoint

## Step 1 — DTO file (DTOs/ folder)
Always use C# records. One file per feature.

```csharp
public record CreateProductRequest(string Name, decimal Price, int Stock);
public record ProductResponse(int Id, string Name, decimal Price, int Stock, DateTime CreatedAt);
```

## Step 2 — Validator (Validators/ folder)

```csharp
public class CreateProductRequestValidator : AbstractValidator<CreateProductRequest>
{
    public CreateProductRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Price).GreaterThan(0);
        RuleFor(x => x.Stock).GreaterThanOrEqualTo(0);
    }
}
```

## Step 3 — Repository (Repositories/ folder)
Always define interface first, then implementation.

```csharp
public interface IProductRepository
{
    Task<List<Product>> GetAllAsync();
    Task<Product?> GetByIdAsync(int id);
    Task<Product> CreateAsync(Product product);
    Task<bool> DeleteAsync(int id);
}

public class ProductRepository(AppDbContext db) : IProductRepository
{
    public async Task<List<Product>> GetAllAsync() =>
        await db.Products.AsNoTracking().ToListAsync();

    public async Task<Product?> GetByIdAsync(int id) =>
        await db.Products.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);

    public async Task<Product> CreateAsync(Product product)
    {
        db.Products.Add(product);
        await db.SaveChangesAsync();
        return product;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var p = await db.Products.FindAsync(id);
        if (p is null) return false;
        db.Products.Remove(p);
        await db.SaveChangesAsync();
        return true;
    }
}
```

## Step 4 — Controller (Controllers/ folder)

```csharp
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public class ProductsController(
    IProductRepository repository,
    IValidator<CreateProductRequest> validator) : ControllerBase
{
    /// <summary>Returns all products.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<ProductResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll()
    {
        var products = await repository.GetAllAsync();
        return Ok(products.Select(MapToResponse));
    }

    /// <summary>Creates a new product.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ProductResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateProductRequest request)
    {
        var validation = await validator.ValidateAsync(request);
        if (!validation.IsValid)
            return ValidationProblem(validation.ToDictionary());

        var product = new Product { Name = request.Name, Price = request.Price, Stock = request.Stock };
        var created = await repository.CreateAsync(product);
        return CreatedAtAction(nameof(GetAll), new { id = created.Id }, MapToResponse(created));
    }

    private static ProductResponse MapToResponse(Product p) =>
        new(p.Id, p.Name, p.Price, p.Stock, p.CreatedAt);
}
```

## Step 5 — Register in Program.cs
```csharp
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IValidator<CreateProductRequest>, CreateProductRequestValidator>();
```

## Checklist
- [ ] DTO records in DTOs/
- [ ] Validator in Validators/
- [ ] Repository interface + class in Repositories/
- [ ] Controller in Controllers/
- [ ] Registered in Program.cs
- [ ] XML doc comments on all public methods
- [ ] csharp-reviewer reviewed it
