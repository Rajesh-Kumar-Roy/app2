---
name: xunit-testing
description: Use when writing xUnit tests for C# controllers, repositories,
             or validators. Triggers on: "write tests", "add tests",
             "unit test", "xUnit", "test this", "cover this with tests".
---

# How to write xUnit tests for this project

## Test file location and naming
- All tests go in the Tests/ folder
- Name format: `{ClassName}Tests.cs`
- Example: `OrdersControllerTests.cs`

## Test method naming
Use this exact pattern — it reads like a sentence:
```
MethodName_Scenario_ExpectedResult

Examples:
  GetAll_WhenOrdersExist_ReturnsOkWithList
  GetById_WhenOrderNotFound_ReturnsNotFound
  Create_WithInvalidEmail_ReturnsBadRequest
  Create_WithValidRequest_ReturnsCreatedOrder
```

## Controller test template

```csharp
// Tests/OrdersControllerTests.cs
using FluentValidation;
using FluentValidation.Results;
using Microsoft.AspNetCore.Mvc;
using Moq;
using OrdersApi.Controllers;
using OrdersApi.DTOs;
using OrdersApi.Models;
using OrdersApi.Repositories;

namespace OrdersApi.Tests;

public class OrdersControllerTests
{
    // ── Setup ─────────────────────────────────────────────────────────
    private readonly Mock<IOrderRepository> _repoMock;
    private readonly Mock<IValidator<CreateOrderRequest>> _validatorMock;
    private readonly OrdersController _controller;

    public OrdersControllerTests()
    {
        _repoMock      = new Mock<IOrderRepository>();
        _validatorMock = new Mock<IValidator<CreateOrderRequest>>();
        _controller    = new OrdersController(_repoMock.Object, _validatorMock.Object);
    }

    // ── GetAll tests ──────────────────────────────────────────────────
    [Fact]
    public async Task GetAll_WhenOrdersExist_ReturnsOkWithList()
    {
        // Arrange
        var orders = new List<Order>
        {
            new() { Id = 1, CustomerName = "Alice", CustomerEmail = "alice@test.com", Items = [] },
            new() { Id = 2, CustomerName = "Bob",   CustomerEmail = "bob@test.com",   Items = [] }
        };
        _repoMock.Setup(r => r.GetAllAsync(1, 10))
                 .ReturnsAsync((orders, 2));

        // Act
        var result = await _controller.GetAll();

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<PagedResponse<OrderResponse>>(ok.Value);
        Assert.Equal(2, response.TotalCount);
    }

    // ── GetById tests ─────────────────────────────────────────────────
    [Fact]
    public async Task GetById_WhenOrderExists_ReturnsOkWithOrder()
    {
        // Arrange
        var order = new Order { Id = 1, CustomerName = "Alice", CustomerEmail = "alice@test.com", Items = [] };
        _repoMock.Setup(r => r.GetByIdAsync(1)).ReturnsAsync(order);

        // Act
        var result = await _controller.GetById(1);

        // Assert
        var ok = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsType<OrderResponse>(ok.Value);
        Assert.Equal(1, response.Id);
        Assert.Equal("Alice", response.CustomerName);
    }

    [Fact]
    public async Task GetById_WhenOrderNotFound_ReturnsNotFound()
    {
        // Arrange
        _repoMock.Setup(r => r.GetByIdAsync(99)).ReturnsAsync((Order?)null);

        // Act
        var result = await _controller.GetById(99);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }

    // ── Create tests ──────────────────────────────────────────────────
    [Fact]
    public async Task Create_WithValidRequest_ReturnsCreated()
    {
        // Arrange
        var request = new CreateOrderRequest(
            "Alice", "alice@test.com",
            [new OrderItemRequest("Laptop", 1, 999.99m)]
        );

        var created = new Order
        {
            Id = 1, CustomerName = "Alice", CustomerEmail = "alice@test.com",
            Amount = 999.99m,
            Items = [new OrderItem { Id = 1, ProductName = "Laptop", Quantity = 1, UnitPrice = 999.99m }]
        };

        _validatorMock
            .Setup(v => v.ValidateAsync(request, default))
            .ReturnsAsync(new ValidationResult());

        _repoMock.Setup(r => r.CreateAsync(It.IsAny<Order>())).ReturnsAsync(created);

        // Act
        var result = await _controller.Create(request);

        // Assert
        var createdResult = Assert.IsType<CreatedAtActionResult>(result);
        var response = Assert.IsType<OrderResponse>(createdResult.Value);
        Assert.Equal("Alice", response.CustomerName);
    }

    [Fact]
    public async Task Create_WithInvalidRequest_ReturnsBadRequest()
    {
        // Arrange
        var request = new CreateOrderRequest("", "not-an-email", []);

        var failures = new List<ValidationFailure>
        {
            new("CustomerName",  "Customer name is required."),
            new("CustomerEmail", "A valid email address is required."),
            new("Items",         "Order must contain at least one item.")
        };

        _validatorMock
            .Setup(v => v.ValidateAsync(request, default))
            .ReturnsAsync(new ValidationResult(failures));

        // Act
        var result = await _controller.Create(request);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result);
    }
}
```

## Validator test template

```csharp
// Tests/OrderValidatorsTests.cs
public class CreateOrderRequestValidatorTests
{
    private readonly CreateOrderRequestValidator _validator = new();

    [Fact]
    public async Task Validate_WithValidRequest_PassesValidation()
    {
        var request = new CreateOrderRequest(
            "Alice Smith", "alice@test.com",
            [new OrderItemRequest("Widget", 2, 9.99m)]
        );
        var result = await _validator.ValidateAsync(request);
        Assert.True(result.IsValid);
    }

    [Fact]
    public async Task Validate_WithEmptyName_FailsValidation()
    {
        var request = new CreateOrderRequest("", "alice@test.com",
            [new OrderItemRequest("Widget", 1, 9.99m)]);
        var result = await _validator.ValidateAsync(request);
        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.PropertyName == "CustomerName");
    }

    [Fact]
    public async Task Validate_WithNoItems_FailsValidation()
    {
        var request = new CreateOrderRequest("Alice", "alice@test.com", []);
        var result = await _validator.ValidateAsync(request);
        Assert.False(result.IsValid);
        Assert.Contains(result.Errors, e => e.PropertyName == "Items");
    }
}
```

## Required NuGet packages for tests
Add to a test project (.csproj):
```xml
<PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.11.0" />
<PackageReference Include="xunit" Version="2.9.0" />
<PackageReference Include="xunit.runner.visualstudio" Version="2.8.2" />
<PackageReference Include="Moq" Version="4.20.72" />
<PackageReference Include="FluentValidation" Version="11.3.0" />
```
