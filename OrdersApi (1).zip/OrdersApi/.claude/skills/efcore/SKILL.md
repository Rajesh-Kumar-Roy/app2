---
name: efcore
description: Use when working with Entity Framework Core — adding entities,
             writing migrations, updating DbContext, or writing queries.
             Triggers on: "add table", "new entity", "database", "migration",
             "DbContext", "EF Core", "add column".
---

# EF Core rules for this project

## Adding a new entity

### Step 1 — Create the model class (Models/ folder)
```csharp
// Models/Product.cs
namespace OrdersApi.Models;

/// <summary>Represents a product in the catalog.</summary>
public class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public int Stock { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
```

### Step 2 — Add DbSet to AppDbContext (Data/AppDbContext.cs)
```csharp
public DbSet<Product> Products => Set<Product>();
```

### Step 3 — Configure in OnModelCreating
```csharp
modelBuilder.Entity<Product>(entity =>
{
    entity.HasKey(p => p.Id);
    entity.Property(p => p.Name).IsRequired().HasMaxLength(200);
    entity.Property(p => p.Price).HasPrecision(18, 2);
    // Optional seed data:
    entity.HasData(
        new Product { Id = 1, Name = "Demo Product", Price = 9.99m, Stock = 100 }
    );
});
```

## Query rules — always follow these

### Read queries — always AsNoTracking
```csharp
// CORRECT
var products = await db.Products.AsNoTracking().ToListAsync();

// WRONG — EF tracks these unnecessarily, wastes memory
var products = await db.Products.ToListAsync();
```

### Related data — always use Include, never lazy load
```csharp
// CORRECT
var order = await db.Orders
    .Include(o => o.Items)
    .AsNoTracking()
    .FirstOrDefaultAsync(o => o.Id == id);

// WRONG — Items will be null or throw
var order = await db.Orders.FirstOrDefaultAsync(o => o.Id == id);
var items = order.Items; // N+1 problem!
```

### Write queries — use FindAsync for single by primary key
```csharp
// CORRECT — uses primary key cache
var product = await db.Products.FindAsync(id);

// OK but slower for PK lookups
var product = await db.Products.FirstOrDefaultAsync(p => p.Id == id);
```

### Pagination pattern
```csharp
var total = await db.Products.CountAsync();
var items = await db.Products
    .AsNoTracking()
    .OrderByDescending(p => p.CreatedAt)
    .Skip((page - 1) * pageSize)
    .Take(pageSize)
    .ToListAsync();
```

## Relationships

### One-to-many (Order has many OrderItems)
```csharp
// In OnModelCreating:
modelBuilder.Entity<Order>()
    .HasMany(o => o.Items)
    .WithOne()
    .HasForeignKey(i => i.OrderId)
    .OnDelete(DeleteBehavior.Cascade);
```

## Common mistakes to avoid
- Never call .Result or .Wait() on EF queries — always await
- Never return EF entities directly from controllers — always map to DTOs
- Never expose DbContext outside the Repository layer
- Always check if entity is null before using it after FindAsync
