using Microsoft.EntityFrameworkCore;
using OrdersApi.Models;

namespace OrdersApi.Data;

/// <summary>
/// Entity Framework Core database context for the Orders API.
/// </summary>
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(o => o.Id);
            entity.Property(o => o.CustomerName).IsRequired().HasMaxLength(100);
            entity.Property(o => o.CustomerEmail).IsRequired().HasMaxLength(200);
            entity.Property(o => o.Amount).HasPrecision(18, 2);
            entity.Property(o => o.Status).HasMaxLength(50);
            entity.HasMany(o => o.Items)
                  .WithOne()
                  .HasForeignKey(i => i.OrderId)
                  .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<OrderItem>(entity =>
        {
            entity.HasKey(i => i.Id);
            entity.Property(i => i.ProductName).IsRequired().HasMaxLength(200);
            entity.Property(i => i.UnitPrice).HasPrecision(18, 2);
        });

        // Seed some demo data
        modelBuilder.Entity<Order>().HasData(
            new Order { Id = 1, CustomerName = "Alice Smith", CustomerEmail = "alice@example.com", Amount = 150.00m, Status = "Completed", CreatedAt = DateTime.UtcNow.AddDays(-5) },
            new Order { Id = 2, CustomerName = "Bob Jones",  CustomerEmail = "bob@example.com",   Amount = 89.99m,  Status = "Pending",   CreatedAt = DateTime.UtcNow.AddDays(-1) }
        );

        modelBuilder.Entity<OrderItem>().HasData(
            new OrderItem { Id = 1, OrderId = 1, ProductName = "Laptop Stand",  Quantity = 1, UnitPrice = 100.00m },
            new OrderItem { Id = 2, OrderId = 1, ProductName = "USB-C Hub",     Quantity = 2, UnitPrice = 25.00m  },
            new OrderItem { Id = 3, OrderId = 2, ProductName = "Wireless Mouse",Quantity = 1, UnitPrice = 89.99m  }
        );
    }
}
