import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { EmployeeStateService } from '../../../services/employee-state.service';


@Component({
  selector: 'app-employee-list-component',
  imports: [CommonModule, RouterModule],
  templateUrl: './employee-list-component.html',
  styleUrl: './employee-list-component.css',
})
export class EmployeeListComponent implements OnInit {
  employeeService = inject(EmployeeStateService);

  ngOnInit() {
    this.employeeService.loadList();
  }

  selectEmployee(id: number) {
    this.employeeService.selectEmployee(id);
  }

  addNew() {
    this.employeeService.startAdd(); // ← was startNew(), renamed to startAdd()
  }

}
