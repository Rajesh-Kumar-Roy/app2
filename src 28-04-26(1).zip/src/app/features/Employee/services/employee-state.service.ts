import { Injectable, inject, signal, computed } from '@angular/core';
import { EmployeeDto, EmployeeListDto, FormMode, PageStatus } from '../models/employee.models';
import { EmployeeApiService } from './employee-api.service';

import { environment } from '../../../../environments/environment';
import { ToastService } from '../../../shared/services/toast.service';

@Injectable({ providedIn: 'root' })
export class EmployeeStateService {
  private api  = inject(EmployeeApiService);
  private toast = inject(ToastService);

  readonly employeeList     = signal<EmployeeListDto[]>([]);
  readonly selectedEmployee = signal<EmployeeDto | null>(null);
  readonly mode             = signal<FormMode>('disabled'); // NEW: start disabled
  readonly status           = signal<PageStatus>('idle');
  readonly searchQuery      = signal('');

  // computed helpers used by template
  readonly loading  = computed(() => this.status() === 'loading');
  readonly saving   = computed(() => this.status() === 'saving');

  readonly filteredList = computed(() => {
    const q = this.searchQuery().toLowerCase();
    return this.employeeList().filter(e =>
      (e.employeeName ?? '').toLowerCase().includes(q) ||
      (e.designationName ?? '').toLowerCase().includes(q) ||
      String(e.id).includes(q)
    );
  });

  // ── Actions ──────────────────────────────────────────────────

  loadList(): void {
    this.status.set('loading');
    this.api.getEmployeeList().subscribe({
      next: list => { this.employeeList.set(list); this.status.set('idle'); },
      error: ()  => { this.toast.error('Failed to load employee list'); this.status.set('error'); }
    });
  }

  selectEmployee(id: number): void {
    this.status.set('loading');
    this.api.getEmployeeDetails(id).subscribe({
      next: emp => {
        this.selectedEmployee.set(emp);
        this.mode.set('view');           // NEW: load in view/readonly mode
        this.status.set('idle');
      },
      error: () => { this.toast.error('Failed to load employee details'); this.status.set('error'); }
    });
  }

  // called when user clicks the Add button on toolbar
  startAdd(): void {
    this.mode.set('add');
    this.selectedEmployee.set(this.emptyEmployee());
  }

  // called when user clicks Edit button
  startEdit(): void {
    this.mode.set('edit');
  }

  // called when user cancels from add mode
  cancelAdd(): void {
    const prev = this.selectedEmployee();
    // if there was a previously selected employee, go back to view it
    // otherwise go back to disabled state
    if (prev?.id) {
      // reload fresh from server to discard any partial state
      this.selectEmployee(prev.id);
    } else {
      this.mode.set('disabled');
      this.selectedEmployee.set(null);
    }
  }

  // called when user cancels from edit mode
  cancelEdit(): void {
    const prev = this.selectedEmployee();
    if (prev?.id) {
      this.selectEmployee(prev.id); // reload from server → view mode
    } else {
      this.mode.set('disabled');
      this.selectedEmployee.set(null);
    }
  }

  save(dto: EmployeeDto): void {
    this.status.set('saving');
    const isEdit = this.mode() === 'edit' && !!dto.id;
    const call   = isEdit
      ? this.api.updateEmployee(dto.id!, dto)
      : this.api.addEmployee(dto);

    call.subscribe({
      next: (res: any) => {
        this.toast.success(isEdit ? 'Employee updated successfully' : 'Employee added successfully');
        this.status.set('idle');
        this.loadList();
        if (isEdit) {
          this.selectEmployee(dto.id!);
        } else {
          // after add, load the newly created employee in view mode
          const newId = res?.id ?? res;
          if (newId) {
            this.selectEmployee(newId);
          } else {
            this.mode.set('disabled');
            this.selectedEmployee.set(null);
          }
        }
      },
      error: () => {
        this.toast.error('Failed to save employee. Please try again.');
        this.status.set('error');
      }
    });
  }

  deleteEmployee(id: number): void {
    this.api.deleteEmployee(id).subscribe({
      next: () => {
        this.toast.success('Employee deleted');
        this.employeeList.update(list => list.filter(e => e.id !== id));
        // FIX 1: after delete → disabled + clear selected
        this.mode.set('disabled');
        this.selectedEmployee.set(null);
      },
      error: () => this.toast.error('Failed to delete employee')
    });
  }

  private emptyEmployee(): EmployeeDto {
    return {
      idClient: environment.idClient,
      employeeName: null,
      idDepartment: 0,
      idSection: 0,
      isActive: true,
      employeeNameBangla: null,
      employeeImage: null,
      fatherName: null,
      motherName: null,
      idReportingManager: null,
      idJobType: null,
      idEmployeeType: null,
      birthDate: null,
      joiningDate: null,
      idGender: null,
      idReligion: null,
      idDesignation: null,
      hasOvertime: false,
      hasAttendenceBonus: false,
      idWeekOff: null,
      address: null,
      presentAddress: null,
      nationalIdentificationNumber: null,
      contactNo: null,
      idMaritalStatus: null,
      employeeDocuments: [],
      employeeEducationInfos: [],
      employeeFamilyInfos: [],
      employeeProfessionalCertifications: []
    };
  }
}
